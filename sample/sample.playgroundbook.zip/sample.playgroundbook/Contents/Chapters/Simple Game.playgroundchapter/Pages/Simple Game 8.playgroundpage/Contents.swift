//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 You have a working game now!
 
 Here are a few optional features you may want to add.
 
 1. Track the number of times the player caught the item successfully. Show the number at the end of the program.
 
 2. Hide the basket and disable its movement when the screen shows "yes" or "no".
 
 (The program at the start has the above features.)
 
 3. Add a "Play Again" feature.
 
 4. Make the user able to set the number of rounds of the falling item.
 
 5. Have more ideas? Perhaps multiple items falling at the same time? Feel free to implement them as well!
 */

//your code here
