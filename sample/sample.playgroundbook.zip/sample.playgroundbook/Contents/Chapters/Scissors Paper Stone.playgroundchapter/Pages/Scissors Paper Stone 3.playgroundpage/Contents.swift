//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Next, let's learn about variables. Variables are a way to store data that can be changed. In Swift, we declare variables by using the following syntax:
 
    var myVariable = 3
    var mySecondVariable = 7
 
 Notice how the first word is uncapitalised, while the first letter of all subsequent words are capitalised? This is a naming convention known as camelCase.
 
 There are a variety of ways to manipulate variables. For instance, we can use the arithmetic operations add(+), subtract(-), multiply(*) and divide(/). There is another special operator, called the modulo(%) operator. a % b basically means "the remainder when a is divided by b".
 
    myVariable = myVariable * myVariable
 
 myVariable is now 3 * 3 = 9
 
    myVariable -= 1
 
 myVariable is now 9 - 1 = 8
 
    mySecondVariable %= 2

 mySecondVariable is now 7 % 2 = 1 (7 divided by 2 gives 3, with a remainder of 1)
 
 Your task: Make a counter that starts at 0, increases by 1 when A is pressed, and decreases by 1 when B is pressed. Show the updated number on the LED Display. Some code has been given to help you start.
 */

//set your variable

onButtonPressed(.A, handler: {
    //make your variable increase by 1 and show the number
    
})
onButtonPressed(.B, handler: {
    //make your variable decrease by 1 and show the number
    
})

