//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 This Playground Book consists of several chapters. Each chapter will cover a different aspect of the Microbit, or guide you in making a Microbit project.
 
 There will be some exercises for you to do along the way. Do try to complete them as much as possible, as they may help you later on. We also recommend that you complete the book in the order given for this reason. This is especially so for the first few chapters, because they cover the fundamentals that you will need throughout the book.
 
 If you find yourself stuck at any point, chances are that you have forgotten something important covered earlier. Do refer to previous exercises to see what you missed. Alternatively, learning how to use a search engine effectively is also a good programming skill to have.
 
 To reset the code at any point, click on the ... menu at the top-right corner and click on Reset Page.
 
 If you see // in the code, these are comments and will not be executed as code.
 
 */




