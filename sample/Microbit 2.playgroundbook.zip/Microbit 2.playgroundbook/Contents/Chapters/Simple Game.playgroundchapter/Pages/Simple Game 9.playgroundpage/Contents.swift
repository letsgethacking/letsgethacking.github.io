//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code


/*:
 Congratulations, you made it!
 As a reward, you get to admire some bad code made by this author, who was trying to figure out how to solve parallel execution. Have a laugh at how glitchy it is. You deserve it.
 */
import Foundation

var delaySoFar = 0.0
func delay(_ seconds: Double, completion: @escaping () -> ()) {
    delaySoFar += seconds
    DispatchQueue.main.asyncAfter(deadline: .now() + delaySoFar) {
        completion()
    }
}

clearScreen()
var basketX = 2
var basketY = 4
plot(x: basketX, y: basketY)
onButtonPressed(.A, handler: {
    unplot(x: basketX, y: basketY)
    basketX -= 1
    if(basketX < 0) {basketX = 0}
    plot(x: basketX, y: basketY)
})
onButtonPressed(.B, handler: {
    unplot(x: basketX, y: basketY)
    basketX += 1
    if(basketX > 4) {basketX = 4}
    plot(x: basketX, y: basketY)
})

var delayTime = 1.0

for j in 1...5{
    var itemX = Int.random(in: 0...4)
    delay(delayTime) {
        clearScreen()
        plot(x: basketX, y: basketY)
        plot(x: itemX, y: 0)
    }
    for k in 1...4 {
        delay(delayTime) {
            plot(x: itemX, y: k)
            unplot(x: itemX, y: k-1)
        }
    }
    delay(delayTime) {
        clearScreen()
        if(basketX==itemX){
            iconImage(.yes).showImage()
        } else {
            iconImage(.no).showImage()
        }
    }
}
