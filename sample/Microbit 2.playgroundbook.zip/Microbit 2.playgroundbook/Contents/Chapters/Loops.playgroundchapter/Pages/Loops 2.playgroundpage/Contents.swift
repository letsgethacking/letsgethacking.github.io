//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Isn't it a pity that the animation only executes once?
 
 Using the for() loop, we can now execute our animation as many times as we want.
 
 But what if we want it to execute forever?
 
 We can use the while() loop. Let's look at an infinite counter.
 
    var counter = 0
    while true {
        showNumber(counter)
        wait(2)
        counter += 1
    }
 
 _Warning: An infinite counter may end up crashing your microbit if you're not careful._
 
 Task: Make the animation you created at the start of this book repeat forever.
 */

