//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
So far, all of our variables involved numbers. Now, let's learn about strings.
 
 Strings are basically a collection of characters.
 
    var myString = "Hello"
    var emptyString = ""
 
 What can we do with strings? Well, we can add strings together to form a longer string by using the + operator. Alternatively, we can use \\(string) to insert strings into other strings.
 
    var someName = "Bobby the Lobby"
    var greeting = "Hi, " + someName
    var sameGreeting = "Hi, \(someName)"
 
 Next, we can also access the nth character in a string.
 
    var p = "abcdefg"
    showString(p[p.index(p.startIndex, offsetBy: 3)] //shows "d"
 
 That's really complicated, so a function is provided below for your use. Try charAt("hello", 2). Also, do note that the first letter has offset 0.
 
 Exercise: Create a message that tells us a name's second letter.

    var someName1 = "Henry"
    var message1 = "The letter is e"
    var someName2 = "Bobby"
    var message2 = "The letter is o"
 
 */

func charAt (_ str: String, _ offset: Int) -> Character {
    return str[str.index(str.startIndex, offsetBy: offset)]
}


