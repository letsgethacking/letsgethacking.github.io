//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Welcome! Let's start by connecting the Microbit to this Playground.
 
 First, you need to ensure that your Microbit is powered. There should be a yellow light to tell you that the Microbit is on.
 
 Do you see the "Pair micro:bit" Button in the top left corner? Click on it and follow the instructions.
 
 After you reset your microbit and click Finish, you may need to manually connect again by clicking connect microbit on the top right hand corner. If you see a frowning face followed by the number 020 on your microbit, you can try resetting your microbit.
 
 After everything is connected, you should see a heart icon displayed on the Microbit. Click on the right arrow at the top to proceed to the next page.
 
 _Your Microbit may be unable to connect to Swift Playground if it is not configured correctly. Visit https://microbit.org/guide/swift-playgrounds/ and follow the instructions under the section "Prepare your micro:bit"._
 */


