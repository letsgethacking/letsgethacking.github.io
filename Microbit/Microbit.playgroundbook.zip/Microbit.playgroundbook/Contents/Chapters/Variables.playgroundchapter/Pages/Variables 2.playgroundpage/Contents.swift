//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Now let's improve our usage of conditionals. Conditionals are the if/else statements that we encountered earlier.
 
 First of all, we can compare 2 numbers by using the greater than (>), smaller than (<), equal to (==), not equal to (!=), greater or equal to (>=), and smaller or equal to (<=) operators.
 
    var myCookies = 4
    var yourCookies = 5
    if myCookies < yourCookies {
        showString("Not fair!")
        myCookies += 1
    }
 
 Your task: Create 2 variables which each have a random value from 1 to 100. If both numbers are the same, show "Same number: " and then the number. Otherwise, show "Larger number: " and then the larger number.
 */

