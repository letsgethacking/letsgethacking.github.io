//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Previously, we gained some idea of how to work with variables. In this chapter, we will be expanding on the knowledge to allow you to apply them in more contexts.
 
 First of all, it is important to have an understanding of variables' counterpart: constants. As the names suggest, whereas variables can _vary_, constants remain _constant_. Now, some of you might be thinking, why can't I use variables for everything, and just don't change the variable if I don't need to? The short answer is yes, you can. However, there are some benefits to using constants, such as making your code easier to understand, or allowing the device running the code to make certain optimisations.
 
 We declare a constant much in the same way we declare a variable, except instead of "var", we use "let" instead.
 
    let daysInAWeek = 7
    let pi = 3.14159
 
 Exercise: In the code below, one finger has been cut off! Oh no! Try changing "var" to "let" to make fingers a constant. What happens?
 */

var fingers = 10
fingers -= 1
