//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Now, we can learn to apply boolean operators. There are 3 main operators that we can use:
 
 1. NOT (!): Negates the condition.
 2. AND (&&): True if both conditions are satisfied.
 3. OR (||): True if _at least_ one condition is satisfied. (You can think of it as and/or)
 
 Exercise: Predict the result of the following code. Then run the code to see if you were correct.
 */

var least = 3
var middle = 5
var most = 13

if !(least < middle && middle != most) {
    most %= middle
    if most >= least || middle == most {
        showNumber(1)
    } else {
        showNumber(2)
    }
} else {
    most %= middle
    if most >= least || middle == most {
        showNumber(3)
    } else {
        showNumber(4)
    }
}
