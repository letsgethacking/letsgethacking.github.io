//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, A, B, C, D, E)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, heart)
//
//#-end-hidden-code
/*:
 It's time to experiment with some inputs. First, let's try using the ADKeyboard in your Tinkerkit!
 
 The ADKeyboard allows you to use up to 5 different buttons on your micro:bit. This is way more than the 2 buttons built into your micro:bit.
 
 First, let's test out your ADKeyboard. You'll need to mount your micro:bit onto the breakout board before continuing.
 
 1. Mount your micro:bit onto the breakout board.
 
 2. Connect the ADKeyboard to pin 1 on your breakout board. (Make sure the correct colours are connected. Generally, G is Black, V is Red and S is Yellow. The same colours go together.)
 
 3. Run the code.
 
 4. Press different buttons on your ADKeyboard and see that the LEDs are plotted according to which button is pressed!
 */
clearScreen()

onADKeyboardKey(.pin1, .A) {
    clearScreen()
    plot(x: 0, y: 0)
}

onADKeyboardKey(.pin1, .B) {
    clearScreen()
    plot(x: 4, y: 0)
}

onADKeyboardKey(.pin1, .C) {
    clearScreen()
    plot(x: 0, y: 2)
}

onADKeyboardKey(.pin1, .D) {
    clearScreen()
    plot(x: 2, y: 2)
}

onADKeyboardKey(.pin1, .E) {
    clearScreen()
    plot(x: 4, y: 2)
}
