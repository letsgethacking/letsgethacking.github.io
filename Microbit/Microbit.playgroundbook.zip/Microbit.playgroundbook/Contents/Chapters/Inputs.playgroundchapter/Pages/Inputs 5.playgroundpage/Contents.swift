//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, A, B, C, D, E)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, heart)
//
//#-end-hidden-code
/*:
 As a bit of a bonus, we get to explore the Potentiometer!
 
 1. Connect the potentiometer to pin 1.
 
 2. Run the code.
 
 3. Turn the potentiometer, and press button A to show the reading.
 
 How this program works is that every time the potentiometer has a new reading, we will store the reading in our own variable storedReading. Then when we press the button, the stored reading will be displayed.
 
 Feel free to experiment with the potentiometer.
 */

clearScreen()
var storedReading = -1
onPotentiometer(.pin1, handler: { reading in
    storedReading = reading
})
onButtonPressed(.A, handler: {
    showNumber(storedReading)
})
