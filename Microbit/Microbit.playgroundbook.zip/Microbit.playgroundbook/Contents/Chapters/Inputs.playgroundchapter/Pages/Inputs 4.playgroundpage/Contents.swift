//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, A, B, C, D, E)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, heart)
//
//#-end-hidden-code
/*:
 Let's create a memory game! (If you can't complete this, don't be discouraged. This is pretty hard, and it is ok to skip if you have tried your best.)
 
 1. Create a random sequence of 10 letters using the letters A to E, ensuring that no 2 consecutive letters are the same, and join them together to create a string. (As you may have seen in the previous page, the ADKeyboard may detect 1 press as multiple presses due to its sampling rate, so it will be much more difficult to program if you try to have consective letters being the same, but you can try if you are adventurous.)
 
 2. Show the string.
 
 3. Afterwards, the user has to press the buttons in the sequence of the letters, then press button A of the microbit to confirm.
 
 4. If the user is correct, show a tick. Otherwise, show a cross. (If the user seems to be pressing a button multiple times, only record it as 1 press.)
 
 */
//your code here
