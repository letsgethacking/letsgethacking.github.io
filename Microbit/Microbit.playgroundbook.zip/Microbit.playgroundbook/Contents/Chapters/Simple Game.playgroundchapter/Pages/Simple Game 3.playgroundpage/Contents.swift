//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Excellent! You now have a basket that you can move left and right.
 
 However, you may have noticed that the basketX value may exceed the range 0 to 4, then the basket will disappear from the screen.
 So, we need to ensure that the basketX value always stays within the range 0 to 4.
 
 There are 2 ways to resolve this:
 
 a) Walled: If the basket is at the leftmost and tries to go left, it stays at the leftmost position. If the basket is at the rightmost and tries to go right, it stays at the rightmost position. (This is what was done in the program at the start.)
 
 b) Wrapped: If the basket is at the leftmost and tries to go left, it wraps around to the rightmost position. If the basket is at the rightmost and tries to go right, it wraps around to the leftmost position.
 
 1. Implement either a) or b). You may need to use if statements.
 
 _Note: You should put your if statements inside of the onButtonPressed() instead of the other way around. Why?_
 */

//your code here
