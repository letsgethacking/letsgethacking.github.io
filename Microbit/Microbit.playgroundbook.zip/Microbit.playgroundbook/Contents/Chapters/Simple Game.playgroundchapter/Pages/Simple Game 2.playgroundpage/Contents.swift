//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 That was great. Now, we need to be able to move the basket left and right. That means we have to store the basket's x-coordinate.
 
 1. Create a variable basketX to store the basket's x-coordinate.
 
 Now, when we click button A, the basket should move to the left, and when we click button B, the basket should move the right.
 
 2. Decrease the variable by 1 when button A is pressed. Increase the variable by 1 when button B is pressed.
 
 We also need to show the new position of the basket.
 
 3. Use unplot() and plot() to show the new position of the basket.
 */

//your code here
