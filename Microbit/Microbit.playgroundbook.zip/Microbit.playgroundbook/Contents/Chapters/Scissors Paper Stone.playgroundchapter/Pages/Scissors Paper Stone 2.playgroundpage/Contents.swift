//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Exercise: Make the display show a tick when button A is pressed and a cross when button B is pressed.

 Hint: You may want to use the "yes" and "no" image icons.
 */

//your code here

