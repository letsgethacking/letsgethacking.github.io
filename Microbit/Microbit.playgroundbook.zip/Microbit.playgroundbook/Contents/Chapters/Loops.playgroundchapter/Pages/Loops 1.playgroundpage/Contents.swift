//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Let's revisit LED Animation. Doesn't the code below seem a bit long? After all, it looks like the same piece of code is being repeated many times.
 
 That's where loops come in! A loop helps us to execute a piece of code multiple times.
 
 The first loop we shall learn is the for() loop. Let's look at an example.
 
    for i in 1...3 {
        showString("HI")
        wait(3)
    }
 
 This piece of code will display "HI" 3 times. What is i? i is the iterator, in this case, a value that goes from 1 to 3.
 
 Your task: Use 2 for() loops to condense the following piece of code. (Hint: You may need to set the value of the y-coordinate using the iterator)
 
 */
clearScreen()

plot(x: 0, y: 0)
wait(0.5)
plot(x: 0, y: 1)
wait(0.5)
plot(x: 0, y: 2)
wait(0.5)
plot(x: 0, y: 3)
wait(0.5)
plot(x: 0, y: 4)
wait(0.5)
unplot(x: 0, y: 0)
wait(0.25)
unplot(x: 0, y: 1)
wait(0.25)
unplot(x: 0, y: 2)
wait(0.25)
unplot(x: 0, y: 3)
wait(0.25)
unplot(x: 0, y: 4)
wait(0.25)
