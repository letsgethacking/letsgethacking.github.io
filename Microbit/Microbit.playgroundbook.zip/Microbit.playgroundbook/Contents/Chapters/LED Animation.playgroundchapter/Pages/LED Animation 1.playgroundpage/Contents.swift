//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 For this first exercise, let's learn how to use the LED Display of the Microbit.
 
 1. At the start of the program, the function clearScreen() is called to ensure all LEDs are off.
 
 2. You use the functions plot() and unplot() to make LEDs on or off.
 
 The LED Display is a 5 by 5 grid.
 
 To determine which LED you are trying to on/off, you may use COORDINATES!
 
 The x-coordinate determines the column of the LED, 0 to 4 from left to right.
 
 The y-coordinate determines the row of the LED, 0 to 4 from top to bottom.
 
 3. The wait() function makes the display freeze for the number of seconds specified.
 
 Edit the following code to create your own sequence!
 */
clearScreen()

plot(x: 0, y: 0)
wait(0.5)
plot(x: 0, y: 1)
wait(0.5)
plot(x: 0, y: 2)
wait(0.5)
plot(x: 0, y: 3)
wait(0.5)
plot(x: 0, y: 4)
wait(0.5)
unplot(x: 0, y: 0)
wait(0.25)
unplot(x: 0, y: 1)
wait(0.25)
unplot(x: 0, y: 2)
wait(0.25)
unplot(x: 0, y: 3)
wait(0.25)
unplot(x: 0, y: 4)
wait(0.25)
