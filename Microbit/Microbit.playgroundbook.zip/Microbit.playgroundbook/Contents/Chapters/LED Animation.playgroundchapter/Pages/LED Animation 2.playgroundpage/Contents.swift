//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 That was fun! However, plotting each LED individually can get a bit repetitive.
 
 Luckily, we have some other functions to help us.
 
 1. showString() displays a string of text, up to 20 characters. It scrolls if there is more than 1 letter.
 
 2. showNumber() displays a number, up to 20 digits. It scrolls if there is more than 1 digit.
 
 3. showImage() displays a image.
 
 How do we define an image? We use MicrobitImage() to plot the points we want to light up manually.
 An "X" represents an LED we want to light up, while a "." represents an LED we want to off. (Look at the code below. What does the MicrobitImage() display?)
 
 Alternatively, we can use iconImage() for existing icons that have been defined for us.
 These include: heart, yes, no, happy, sad, tShirt, duck, house, stickFigure, ghost, sword, giraffe, skull, umbrella, quarterNote, eighthNote, pitchfork, triangle, diamond, square, north, northEast, etc.
 
 Run the code provided below. Then remove 1 or more wait statements and run again. What happens?
 */
clearScreen()

showString("I")
wait(2)
showString("HI")
wait(3)
showNumber(1)
wait(2)
showNumber(11)
wait(3)
MicrobitImage("""
x.x.x
x.x.x
xxx.x
x.x.x
x.x.x
""").showImage()
wait(2)
iconImage(.happy).showImage()
wait(2)
