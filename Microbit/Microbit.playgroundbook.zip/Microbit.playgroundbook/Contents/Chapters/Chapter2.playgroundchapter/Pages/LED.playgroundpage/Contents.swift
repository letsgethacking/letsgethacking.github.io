//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, A, B, C, D, E)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, heart)
//
//#-end-hidden-code
/*:#localized(key: "Chapter2Page1Narrative")
 Now that you're familiar with the ADKeyboard, let's get rolling with the LEDs.

 There are a few LEDs of differing colours.

 For this exercise, you are going to lighten up a different coloured LED for each button pressed oon the ADKeyboard.

 You'll need to mount your micro:bit onto the breakout board before continuing.

 1. Mount your micro:bit onto the breakout board.

 2. Connect the ADKeyboard to pin 0 on your breakout board.

 3. Connect the 3 LEDs to pins 1 to 3.

 4. Run the code.

 4. Press different buttons on your ADKeyboard and see that different LEDs light to to different pressed buttons!
 */
clearScreen()

onADKeyboardKey(.pin0, .A, handler: {
    setLED(.pin1, state: true)
    setLED(.pin2, state: false)
    setLED(.pin3, state: false)
})

onADKeyboardKey(.pin0, .B, handler: {
    setLED(.pin1, state: false)
    setLED(.pin2, state: true)
    setLED(.pin3, state: false)
})

onADKeyboardKey(.pin0, .C, handler: {
    setLED(.pin1, state: false)
    setLED(.pin2, state: false)
    setLED(.pin3, state: true)
})
