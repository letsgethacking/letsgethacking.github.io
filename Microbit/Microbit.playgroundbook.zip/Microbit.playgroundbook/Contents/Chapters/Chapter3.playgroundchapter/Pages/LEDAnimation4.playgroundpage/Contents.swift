//#-hidden-code
//
//  Contents.swift
//
//#-end-hidden-code
/*:#localized(key: "Page4Narrative")
 Just now, you may have noticed the "wait" function.
 
 With "wait", images or numbers wait some seconds, and won't go away so quickly.
 
 We use "wait" to create animations.
 
 1.  Run the code below to see what happens.
 
 Below, you also see a "while" loop. This makes the enclosed code keep repeating.
 
 2. Use "Step Through My Code" to see the "while" loop in action.
 
 Now that you understand a basic animation, edit the code below to create your own animation!
 */

//#-hidden-code
import PlaygroundSupport
import Foundation
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, ghost, angry, umbrella)

func wait(_ delayInSeconds: Double) {
    usleep(UInt32(delayInSeconds * 1_000_000))
}
//#-end-hidden-code
//#-editable-code
while true {
    let image1ToDisplay = iconImage(.heart)
    image1ToDisplay.showImage()
    
    wait(0.5)
    
    let image2ToDisplay = iconImage(.smallHeart)
    image2ToDisplay.showImage()
    
    wait(0.5)
}
//#-end-editable-code
