//
//  tinkercademy.swift
//  Microbit 2
//

public enum ADKey: Int {
    case None, A, B, C, D, E
}

public typealias ReadPIRHandler = (Bool) -> Void
public typealias ReadCrashHandler = (Bool) -> Void
public typealias ReadMoistureHandler = (Int) -> Void
public typealias ReadADKeyboardHandler = (ADKey) -> Void
public typealias ReadPotentiometerHandler = (Int) -> Void

public func onMoistureSensor(_ pin: BTMicrobit.Pin, handler: @escaping ReadMoistureHandler) {
    setInputPins([pin])
    setAnaloguePins([pin])
    onPins { pinStore in
        guard let pinValue = pinStore[pin] else { return }
//            let mappedPinValue = Int(Float(pinValue) / 950 * 100)
//            let mappedPinValue = pinValue / 3
        handler(pinValue)
    }
    wait(5)
}

public func setLED(_ pin: BTMicrobit.Pin, state: Bool) {
    setInputPins([], outputPins: [pin])
    setAnaloguePins([], digitalPins: [pin])
    writePins([pin: state ? 1 : 0])
}

public func onPIR(_ pin: BTMicrobit.Pin, handler: @escaping ReadPIRHandler) {
    setInputPins([pin])
    setAnaloguePins([], digitalPins: [pin])
    onPins { pinStore in
        guard let pinValue = pinStore[pin] else { return }
        handler(pinValue == 1)
    }
}

public func onPotentiometer (_ pin: BTMicrobit.Pin, handler: @escaping ReadPotentiometerHandler) {
    setPinsPeriod(50)
    setInputPins([pin])
    setAnaloguePins([pin])
    onPins { pinStore in
        guard let pinValue = pinStore[pin] else { return }
        handler(pinValue)
    }
}

public func onADKeyboard(_ pin: BTMicrobit.Pin, handler: @escaping ReadADKeyboardHandler) {
    setPinsPeriod(50)
    setInputPins([pin])
    setAnaloguePins([pin])
    onPins { pinStore in
        guard let pinValue = pinStore[pin] else { return }
        let key: ADKey
        switch pinValue {
        case 0..<10:
            key = ADKey.A
        case 45..<61:
            key = ADKey.B
        case 90..<105:
            key = ADKey.C
        case 135..<145:
            key = ADKey.D
        case 15..<35: //for some reason it is like that contrary to what research would tell you (took many hours of brute force no thanks) -LCR
            key = ADKey.E
        default:
            key = ADKey.None
        }
        /* previously
         case 0..<10:
         key = ADKey.A
         case 40..<61:
         key = ADKey.B
         case 80..<111:
         key = ADKey.C
         case 130..<151:
         key = ADKey.D
         case 530..<561:
         key = ADKey.E
         default:
         key = ADKey.None
         */
        handler(key)
    }
}

public func onADKeyboardKey(_ pin: BTMicrobit.Pin, _ key: ADKey, handler: @escaping EventHandler) {
    onADKeyboard(pin) { pressedKey in
        guard pressedKey == key else { return }
        handler()
    }
}

public func onCrashSensor(_ pin: BTMicrobit.Pin, handler: @escaping ReadCrashHandler) {
    setInputPins([pin])
    setAnaloguePins([], digitalPins: [pin])
    onPins { pinStore in
        guard let pinValue = pinStore[pin] else { return }
        handler(pinValue == 1)
    }
}
