//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Exercise: Using what you have learnt, make a program that counts from 1 to 100 repeatedly. However, when the number is a multiple of 3, make it display "Fizz" instead. If the number is a multiple of 5, make it display "Buzz". And if the number is a multiple of both 3 and 5, make it display "FizzBuzz". (Hint: You may need the modulo operator)
 */

//your code here
