//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
We're almost there! Now, we need to detect whether the item has been successfully caught by the basket.
 
 1. Add an if/else statement at an appropriate place to detect whether the item has been caught. (Hint: this should be when the item is at y-coordinate 4. Since the y-coordinates will be the same, you just need to check if the x-coordinates are the same as well.)
 
 2. If the item is caught, show the icon "yes" for the same amount of delay time as that of the falling item. Otherwise, show the icon "no".
 
 
 */

