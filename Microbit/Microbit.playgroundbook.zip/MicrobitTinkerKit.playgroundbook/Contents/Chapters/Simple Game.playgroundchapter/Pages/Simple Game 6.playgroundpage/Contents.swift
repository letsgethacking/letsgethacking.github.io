//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
Alright! You now have the falling item ready. Now, we need to combine the basket and the item.
 
1. Copy your code for both the basket and the item over. Run the code.
 
 You might notice that your basket seems to be stuck. This is because wait() statements practically freezes the program. This is a very annoying problem to deal with. Luckily, this author has done all the hard work and research for you, so now you can solve this problem with only a few lines of code.
 
 2. Add these 2 lines of code to the very beginning of your program.
 
        import Foundation
        let concurrentQueue = DispatchQueue(label: "concurrent", attributes: .concurrent)
 
 What this does is that it imports a Swift library called Foundation, which provides additional functions for us to use. Then it sets up a concurrent queue. This tells the program to execute different parts of the code simultaneously, so that even when it is wait() -ing, the basket can continue moving
 
 3. Put the code for the basket within the following piece of code. Do the same with the item. _For code that runs before the main program starts, you may leave it outside of the concurrentQueue. For example, the initialisation of variables (when you declare var something = somethingg) or the plotting of the initial position of the basket._
 
        concurrentQueue.async {
            //code for basket or item
        }
 
 Hopefully, if you did everything correctly, you should now be able to move your basket when the item is falling down.
 */

//your code here

