//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//
//#-end-hidden-code
/*:
  It's time for a project. In this project, you will create a simple game on the microbit using its display. The player will use the buttons to move a basket at the bottom of the LED, in order to catch a falling item.
 
  Here, a sample has been provided for you to try it out and understand how the game works. Then, you will be programming the game yourself.
 
 1. Click on "Run My Code" and try out the game.
 */



//#-hidden-code

import Foundation
let concurrentQueue = DispatchQueue(label: "concurrent", attributes: .concurrent)

var repeats: Int? = nil
var startSpeed: Int? = nil
var endSpeed: Int? = nil
//if you can read this code you get to modify repeats, startSpeed and endSpeed :)

//#-end-hidden-code
//#-editable-code
//i love games
//#-end-editable-code
//#-hidden-code
clearScreen()
var basketX = 2
var basketY = 4
plot(x: basketX, y: basketY)
var freezeControls = false
var success = 0
var itemX = 0
var lastRow = false

concurrentQueue.async {
    onButtonPressed(.A, handler: {
        if(!freezeControls){
            if(!(lastRow && basketX == itemX)){
                unplot(x: basketX, y: basketY)
            }
            basketX -= 1
            if(basketX < 0) {basketX = 0}
            plot(x: basketX, y: basketY)
        }
    })
    onButtonPressed(.B, handler: {
        if(!freezeControls){
            if(!(lastRow && basketX == itemX)){
                unplot(x: basketX, y: basketY)
            }
            basketX += 1
            if(basketX > 4) {basketX = 4}
            plot(x: basketX, y: basketY)
        }
    })
}

concurrentQueue.async {
    for i in (startSpeed ?? 1)...(endSpeed ?? 10){
        var delayTime = 1.0/Double(i)
        for j in 1...(repeats ?? 3){
            itemX = Int.random(in: 0...4)
            plot(x: basketX, y: basketY)
            plot(x: itemX, y: 0)
            freezeControls = false
            
            for k in 1...4 {
                wait(delayTime)
                plot(x: itemX, y: k)
                unplot(x: itemX, y: k-1)
            }
            lastRow = true
            wait(delayTime)
            freezeControls = true
            clearScreen()
            if(basketX==itemX){
                success+=1
                iconImage(.yes).showImage()
            } else {
                iconImage(.no).showImage()
            }
            wait(delayTime)
            clearScreen()
            lastRow = false
        }
    }
    showNumber(success)
}

//#-end-hidden-code
