//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Now it is time to create your own LED Animation!
 
 Use any of the functions you have learnt:
 
 clearScreen(), plot(), unplot(), wait(), showString(), showNumber(), showImage()
 
 If you cannot remember the syntax, feel free to look at the previous 2 examples.
 
 When you are done, show off your animation to others!
 */

//your code here
