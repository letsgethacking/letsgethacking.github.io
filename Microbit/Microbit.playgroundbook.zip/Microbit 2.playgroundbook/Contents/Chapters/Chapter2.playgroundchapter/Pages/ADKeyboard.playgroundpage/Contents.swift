//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, A, B, C, D, E)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, heart)
//
//#-end-hidden-code
/*:#localized(key: "Chapter2Page1Narrative")
 Let's try using the ADKeyboard in your Tinkerkit!
 
 The ADKeyboard allows you to use up to 5 different buttons on your micro:bit! This is way more than the 2 buttons built into your micro:bit.
 
 For this exercise, you are going to display various images on your micro:bit when pressing buttons on your ADKeyboard.
 
 You'll need to mount your micro:bit onto the breakout board before continuing.
 
 1. Mount your micro:bit onto the breakout board.
 
 2. Connect the ADKeyboard to pin 1 on your breakout board.
 
 3. Run the code.
 
 4. Press different buttons on your ADKeyboard and see that your micro:bit displays different images!
 */
clearScreen()

onADKeyboardKey(.pin1, .A) {
    let imageToDisplay = iconImage(./*#-editable-code*/heart/*#-end-editable-code*/)
    imageToDisplay.showImage()
}

onADKeyboardKey(.pin1, .B) {
    let imageToDisplay = iconImage(./*#-editable-code*/duck/*#-end-editable-code*/)
    imageToDisplay.showImage()
}

onADKeyboardKey(.pin1, .C) {
    let imageToDisplay = iconImage(./*#-editable-code*/giraffe/*#-end-editable-code*/)
    imageToDisplay.showImage()
}

onADKeyboardKey(.pin1, .D) {
    let imageToDisplay = iconImage(./*#-editable-code*/happy/*#-end-editable-code*/)
    imageToDisplay.showImage()
}

onADKeyboardKey(.pin1, .E) {
    let imageToDisplay = iconImage(./*#-editable-code*/target/*#-end-editable-code*/)
    imageToDisplay.showImage()
}
