//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, A, B, C, D, E)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, heart)
//
//#-end-hidden-code
/*:#localized(key: "Chapter2Page1Narrative")
 
 Let's tell the user whether the connected moisture sensor is wet or dry. Connect the moisture sensor to pin 1.

 */
clearScreen()

onMoistureSensor(.pin1) { pinValue in
    showString("\(pinValue)")
}

