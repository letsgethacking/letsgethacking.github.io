//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
Great! Now we have a falling item. Obviously, we want to have the object falling many times. So let's do that.
 
 1. Make a for() loop to make the object fall 3 times. Make sure it starts from a random x-ccordinate for each fall. You may also want to have a delay of 1 second between falls.
 
 2. Use a variable to store the delay time (1 second) for the item falling, so that we can change the delay time easily by setting the variable, instead of having to manually set the delay time at multiple places.
 
 3. Use another for() loop that runs whatever code you have 10 times. Then, set the inner loop's delay time to be 1 divided by the iterator of the outer loop. _Use 1.0/Double(iterator). The reason for this is that if you use integers (no decimal points) instead of doubles (with decimal points), the program will think that you want an integer result, so it will round the result, and your delay time will be either 0 or 1 second, and cannot be something in between._
 
 _Caution: Use different names for the iterators of the for() loops, otherwise they may interfere._
 */

//your code here
