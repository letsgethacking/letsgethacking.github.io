//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Next, we need to add the falling item.
 
 _Warning: Do not copy your code from the previous page over. We will be combining the basket and falling item later. There will be a few things we need to resolve when they are combined, so leave the code for the basket as it is now._
 
 1. Use a for() loop to make the item fall from (0,0) to (0,4), taking 1 second of delay between positions. (Hint: What function gives a delay?)
 
 2. We want the item to start from a random position. Use Int.random() to generate a random starting x-coordinate, and store it in a variable called itemX. Then make the item fall from (itemX, 0) to (itemX, 4).

 */

//your code here


