//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 To start, let's make the basket. At the start, we want the basket to be at the center of the bottom row. What coordinates should be plotted?
 
 1. Show the basket on the LED Display by plotting its start position.
 */

//your code here
