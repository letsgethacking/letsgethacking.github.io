//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, A, B, C, D, E)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, heart)
//
//#-end-hidden-code
/*:
 To use the ADKeyboard, we have to learn its syntax.
 
    onADKeyboardKey(.pin1, .A) {
        //handler
    }
 
 Here, we can see that there are 2 arguments to the function, namely the pin, and the button name. Since we connected the ADKeyboard to pin 1, we use .pin1 in our code. The other pins that are compatible with the ADKeyboard are pins 0 and 2.
 
 The .A part of the code corresponds to the pressed button on the ADKeyboard. So for the example above, the handler is called when button A of an ADKeyboard connected to pin 1 is pressed.
 
 Try to get a different icon to display when each button is pressed!
 
 Notes:
 
 1. The ADKeyboard takes readings every 50 milliseconds, so it may miss very quick inputs. What this means is that if you are developing a fast reaction game, for example, you could use the built-in Microbit buttons for the quick inputs and the ADKeyboard for inputs that are not so urgent.
 
 2. If your ADKeyboard is not working properly, this may be because of a connection issue. The ADKeyboard works by detecting the intensity of signal delivered to the Microbit, hence if it is not properly connected, the readings may differ. To solve this problem, try disconnecting and reconnecting the ADKeyboard, then placing it on a flat surface.
 */

//your code here

