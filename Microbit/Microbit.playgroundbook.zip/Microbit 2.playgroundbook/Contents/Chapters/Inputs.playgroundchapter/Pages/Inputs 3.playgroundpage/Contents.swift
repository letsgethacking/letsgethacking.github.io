//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, A, B, C, D, E)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, heart)
//
//#-end-hidden-code
/*:
 Alright, now that we have 5 buttons to play around with, let's program a simple movement control scheme.
 
 1. At the start, make the centre of the 5 by 5 LED Display light up. This represents your character.
 
 2. When button B is pressed, make your character move upwards. When button C is pressed, make it move left. Buttons D and E correspond to down and right respectively.
 
 3. When button A is pressed, reset your character to the center.
 
 4. Make sure your character does not move out of the screen.
 */
//your code here

