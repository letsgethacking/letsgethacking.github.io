//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Now, let's learn about event handlers.
 
 An event handler is a piece of code that will execute whenever a particular event occurs.
 
 Various types of events can be triggered: for example, when the accelerometer senses an orientation change, or when the micro-bit receives a radio signal.
 
 For now, let us focus on buttons. The microbit comes with 2 buttons on either side of the LED Display, labelled A and B.
 
 We use the function onButtonPressed() to detect when a button is pressed. We have to specify which button we are trying to detect and the handler for that button.
 
 In the example below, the display shows the letter corresponding to the button being pressed.
 */
clearScreen()
onButtonPressed(.A, handler: {
    showString("A")
})
onButtonPressed(.B, handler: {
    showString("B")
})

