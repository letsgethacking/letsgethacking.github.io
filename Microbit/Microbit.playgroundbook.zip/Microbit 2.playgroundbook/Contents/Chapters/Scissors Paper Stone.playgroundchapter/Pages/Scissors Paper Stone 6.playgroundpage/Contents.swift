//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 It's time for a test of what you have learnt so far.
 
 Make the program randomly display rock, paper or scissors when button A is pressed.
 Play against your friends' programs!
 
 Then, implement a counter that keeps tracks of the number of times your program wins.
 If your program wins, button B is pressed, and the counter is incremented by 1 and displayed.
 */

//good luck have fun
