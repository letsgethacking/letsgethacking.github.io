//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
Now, let's make the microbit display a random image from a list of images.
 
 First, we need to generate a random number.
 Then, based on the number generated, we will display a particular image.
 
 To accomplish this, we can use if statements. An if statement executes a block of code if a given condition is satisfied.
 
    var myVariable = 1
    //notice how this is "=", used for assigning values
    if myVariable == 2 {
    //while this is "==", used for comparing values
        showString("Two")
    } else {
        showString("NotTwo")
    }
 
  Note: onButtonPressed() triggers _whenever_ the button is pressed, not _if_ the button is pressed. To check if a button is pressed and some other condition is satisfied, you should check the condition inside the button's handler. That is, instead of putting onButtonPressed() in your if() statement, put your if() statement inside of onButtonPressed()'s handler. This applies for other event handlers as well.
 */

onButtonPressed(.B, handler: {
    var randomNumber = Int.random(in: 1...99) //random number from 1 to 99
    if randomNumber % 2 == 0 { //this checks if randomNumber leaves a remainder of 0 when divided by 2 (which is when randomNumber is even)
        iconImage(.triangle).showImage()
    }
    
    if randomNumber == 1 {
        iconImage(.heart).showImage()
    } else if randomNumber == 3 {
        iconImage(.diamond).showImage()
    } else if randomNumber % 2 == 1 {
        //this code runs if random number is odd but not 1 and 3 (why?)
        iconImage(.house).showImage()
    }
    
})


