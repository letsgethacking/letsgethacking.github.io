//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Let's learn how to use the Int.random() function to generate a random number!
 
 First, we need to know about ranges in Swift.
 We use the ... operator to indicate a range from the starting value to the ending value.
 We use the ..< operator to indicate a range from the starting value but not including the ending value.
 
 We are able to generate a random number by passing a range to the Int.random() function.
 (Note that Int.random() produces *Int*egers, which are numbers without decimal points.)
 
 For example,
 
    var singleDigit = Int.random(in: 1..<10)
 
 gives us values from 1 to 9, but not 10.
 
 Exercise: Display a random 3-digit number when button A is pressed. (What are the start and end values?)
 */

//your code here
