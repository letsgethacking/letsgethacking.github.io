//#-hidden-code
//
//  Contents.swift
//
//#-end-hidden-code
/*:#localized(key: "Page3Narrative")
 Sometimes, you do not have to create your designs from scratch. The micro:bit comes with built in functions to display Strings, numbers and pre-loaded icons!
 
 1. Run the code below and notice what happens.
 2. Replace the number "1" with any number you want
 3. Replace the String "I am String." with "Hello World."
 4. Replace the icon "heart" with an icon of your choice.
 5. Run the code.
 
 */
//#-hidden-code
import PlaygroundSupport
import Foundation
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, duck, happy, target, chessboard, rabbit, giraffe, ghost, angry, umbrella)

func wait(_ delayInSeconds: Double) {
    usleep(UInt32(delayInSeconds * 1_000_000))
}
//#-end-hidden-code

showNumber(/*#-editable-code text to display*/1/*#-end-editable-code*/)

wait(2)
let textToDisplay = /*#-editable-code text to display*/"I am String."/*#-end-editable-code*/
showString(textToDisplay)

wait(Double(textToDisplay.count))
let imageToDisplay = iconImage(./*#-editable-code icon name*/heart/*#-end-editable-code*/)
imageToDisplay.showImage()
