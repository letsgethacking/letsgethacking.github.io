//#-hidden-code
//
//  Contents.swift
//
//#-end-hidden-code
/*:#localized(key: "Page1Narrative")
 The face of the micro:bit is made by a large 5 x 5 LED display.
 
 You can write programs to turn on each individual LED.
 
 The LED display can be located by coordinates (x,y), where x is the column the LED is in, and y is the row the LED is in.
 
 The top left corner is (0,0). The bottom right corner is (4,4). It is like plotting a graph!
 
 1. Run the code below and notice what happens.
 2. Change the numbers '2' and '3' with any other SINGLE number LESS THAN OR EQUAL TO 4.
 3. Run the code again.
 4. Notice which LED lights up
 5. Now replace the numbers again.
 6. Can you figure out how to identify each LED?
 
 Now that you know the identity of each LED, the next chapter will teach you a fast way to light up many LEDs at once.
 */
//#-hidden-code
import PlaygroundSupport

//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, displayText(_:))

//#-end-hidden-code

plot(x:/*#-editable-code text to display*/2/*#-end-editable-code*/,y:/*#-editable-code text to display*/3/*#-end-editable-code*/)
