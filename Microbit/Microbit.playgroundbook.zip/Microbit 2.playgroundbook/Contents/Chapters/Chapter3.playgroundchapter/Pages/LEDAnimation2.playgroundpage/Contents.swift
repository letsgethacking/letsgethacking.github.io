//#-hidden-code
//
//  Contents.swift
//
//#-end-hidden-code
/*:#localized(key: "Page2Narrative")
 Now that you can light up individual LEDs, do you wonder how you can quickly light up many LEDs at once?
 
 To create a pattern of many LEDs, you create a frame. "X" indicates the LED lights up, while "." indicates the LED does not light up.
 
 Then, you get the micro:bit to show the frame.
 
 1. Run the code below and notice what happens.
 2. Change the frame design to display a smiley face.
 3. Run the code again.
 4. Create other designs you want the micro:bit to show!
 
 */
//#-hidden-code
import PlaygroundSupport

//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, displayText(_:))

//#-end-hidden-code
//#-editable-code
let frameOne = MicrobitImage("""
. X . X .
X X X X X
X X X X X
. X X X .
. . X . .
""")
//#-end-editable-code
frameOne.showImage()
