//#-hidden-code
//
//  Contents.swift
//
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//
//#-end-hidden-code
/*:
 Lastly, let's learn how to convert between numbers and strings!
 
 First, we can convert a number to a string directly.
 
    var two = String(2)
    var twenty = two + "0"
 
 However, when converting a string to a number, we must be more careful, because not all strings can be converted to numbers, while all numbers can be converted into strings easily. The following example causes an error.
 
    var tenPlusTenBad = 0
    tenPlusTenBad = Int(twenty)
 
 It is better to explicitly declare the variables type as in the following:
 
    var tenPlusTen: Int? = 0
    tenPlusTen = Int(twenty)
 
 The question mark _?_ tells Swift that we are aware of the possibility of things going wrong when the string cannot be converted, in which case tenPlusTen will be "nil".
 
Because of the possibility of it being "nil", we have to unwrap the value of tenPlusTen when we want to use it by using "!" _behind_ the value (recall that putting ! in front of something is the boolean NOT). For example,
 
    showNumber(tenPlusTen) //gives an error
    showNumber(tenPlusTen!) //works

 
 Task: Generate a random number from 1 to 9. If for example the number is 3, show "Player 3 Wins!". Make sure that the spaces and capitalisations are correct.
 */

//your code here

