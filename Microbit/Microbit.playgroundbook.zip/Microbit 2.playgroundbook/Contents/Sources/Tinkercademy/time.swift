//
//  time.swift
//  Microbit 2
//

import Foundation

public func wait(_ delayInSeconds: Double) {
    usleep(UInt32(delayInSeconds * 1_000_000))
}
